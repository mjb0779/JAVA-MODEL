package com.example.mjb0779.gamever1.eyegame;

public interface ILoader {

	public String Fetch() throws Exception;
}
