package com.example.mjb0779.gamever1.eyegame;

import java.io.File;
import java.io.IOException;

public interface ISaver {

	public void push(File file, String data) throws IOException ;
}
