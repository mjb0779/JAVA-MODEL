package com.example.mjb0779.gamever1.eyegame;

public enum CONST {

	PLAYER,
	BOXES,
	GOALS,
	
}
