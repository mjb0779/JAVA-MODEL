package eyegame;

public enum CONST {

	PLAYER,
	BOXES,
	GOALS,
	
}
