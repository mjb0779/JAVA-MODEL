package eyegame;

public class MapEditor {

	public int sizeX;
	public int sizeY;
	public MapEditor(int newSizeX, int newSizeY) {
		this.sizeX = newSizeX;
		this.sizeY = newSizeY;
	}
	
	public void generateMap() {
		
	}
}
