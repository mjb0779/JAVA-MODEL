package eyegame;

public interface ILoader {

	public String Fetch() throws Exception;
}
